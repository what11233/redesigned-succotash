## Packages
framer-motion | Smooth page transitions and micro-interactions for a premium mobile feel
react-hook-form | Form state management for character creation
@hookform/resolvers | Zod validation integration for forms
clsx | Utility for constructing className strings
tailwind-merge | Utility for merging tailwind classes without conflicts
date-fns | Date formatting for chat timestamps
react-intersection-observer | For auto-scrolling chat to bottom efficiently

## Notes
- Tailwind config needs to extend font families: 'display' mapped to var(--font-display) and 'body' mapped to var(--font-body).
- Uses Fetch API for Server-Sent Events (SSE) to handle streaming chat responses.
- Assuming Replit Auth is configured; redirects to /api/login when not authenticated.
