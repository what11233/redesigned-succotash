import { Heart } from "lucide-react";
import { motion } from "framer-motion";
import { clsx } from "clsx";

interface RelationshipMeterProps {
  score: number; // -100 to 100
  size?: "sm" | "md" | "lg";
}

export function RelationshipMeter({ score, size = "md" }: RelationshipMeterProps) {
  // Normalize score to 0-100 for display width
  const normalizedScore = Math.max(0, Math.min(100, (score + 100) / 2));
  
  // Determine color based on score
  const getColor = () => {
    if (score < -30) return "from-destructive to-red-600";
    if (score < 20) return "from-zinc-500 to-zinc-400";
    if (score < 60) return "from-accent to-purple-500";
    return "from-primary to-pink-500";
  };

  const sizes = {
    sm: "w-24 h-1.5",
    md: "w-32 h-2",
    lg: "w-48 h-3"
  };

  const iconSizes = {
    sm: "w-3 h-3",
    md: "w-4 h-4",
    lg: "w-5 h-5"
  };

  return (
    <div className="flex items-center gap-3">
      <div className={clsx("relative rounded-full bg-secondary overflow-hidden", sizes[size])}>
        <motion.div 
          className={clsx("absolute top-0 left-0 bottom-0 bg-gradient-to-r rounded-full", getColor())}
          initial={{ width: 0 }}
          animate={{ width: `${normalizedScore}%` }}
          transition={{ type: "spring", stiffness: 50, damping: 15 }}
        />
      </div>
      <div className={clsx(
        "flex items-center justify-center rounded-full glass-panel",
        size === 'sm' ? 'w-6 h-6' : size === 'md' ? 'w-8 h-8' : 'w-10 h-10'
      )}>
        <Heart className={clsx(
          iconSizes[size], 
          score > 50 ? "text-primary fill-primary" : "text-muted-foreground"
        )} />
      </div>
    </div>
  );
}
