import { Link, useLocation } from "wouter";
import { Home, Compass, MessageCircle, User as UserIcon } from "lucide-react";
import { clsx } from "clsx";
import { motion } from "framer-motion";

export function BottomNav() {
  const [location] = useLocation();

  const navItems = [
    { href: "/", icon: Home, label: "Home" },
    { href: "/discover", icon: Compass, label: "Discover" },
    { href: "/chats", icon: MessageCircle, label: "Chats" },
    { href: "/profile", icon: UserIcon, label: "Profile" },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 px-4 pb-6 pt-2 pointer-events-none">
      <div className="max-w-md mx-auto pointer-events-auto">
        <nav className="glass-panel rounded-full px-6 py-3 flex items-center justify-between shadow-2xl">
          {navItems.map((item) => {
            const isActive = location === item.href || (item.href !== '/' && location.startsWith(item.href));
            const Icon = item.icon;
            
            return (
              <Link key={item.href} href={item.href} className="relative group p-2">
                <div className={clsx(
                  "flex flex-col items-center gap-1 transition-colors duration-300",
                  isActive ? "text-primary" : "text-muted-foreground hover:text-foreground"
                )}>
                  <Icon className="w-6 h-6" strokeWidth={isActive ? 2.5 : 2} />
                  <span className="text-[10px] font-medium hidden sm:block">{item.label}</span>
                </div>
                
                {isActive && (
                  <motion.div
                    layoutId="bottom-nav-indicator"
                    className="absolute -bottom-3 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-primary glow-shadow"
                  />
                )}
              </Link>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
