import { Link } from "wouter";
import { Heart } from "lucide-react";
import { motion } from "framer-motion";

interface Character {
  id: number;
  name: string;
  scenario: string;
  imageUrl?: string | null;
}

export function CharacterCard({ character, index }: { character: Character; index: number }) {
  // Generate a predictable avatar if none exists
  const fallbackImg = `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(character.name)}&backgroundColor=b6e3f4,c0aede,d1d4f9,ffdfbf`;
  const imgSource = character.imageUrl || fallbackImg;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.1 }}
    >
      <Link href={`/character/${character.id}`} className="block group">
        <div className="relative aspect-[3/4] rounded-2xl overflow-hidden bg-card border border-border transition-all duration-300 hover:border-primary/50 hover:shadow-xl hover:shadow-primary/20">
          <img 
            src={imgSource} 
            alt={character.name}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
          
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent flex flex-col justify-end p-4">
            <h3 className="font-display text-xl font-bold text-white mb-1">{character.name}</h3>
            <p className="text-sm text-white/70 line-clamp-2 leading-snug">
              {character.scenario}
            </p>
            
            <div className="absolute top-3 right-3 w-8 h-8 rounded-full glass-panel flex items-center justify-center opacity-0 transform translate-y-2 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300">
              <Heart className="w-4 h-4 text-primary fill-primary/20" />
            </div>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
