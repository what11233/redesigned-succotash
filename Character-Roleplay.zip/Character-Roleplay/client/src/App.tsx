import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";

import Home from "./pages/Home";
import { CharacterDetail } from "./pages/CharacterDetail";
import { CreateCharacter } from "./pages/CreateCharacter";
import { ChatList } from "./pages/ChatList";
import { ChatView } from "./pages/ChatView";
import { BottomNav } from "./components/BottomNav";

function Router() {
  return (
    <>
      <Switch>
        <Route path="/" component={Home}/>
        <Route path="/discover" component={Home}/> {/* Can be unique later */}
        <Route path="/create" component={CreateCharacter}/>
        <Route path="/character/:id" component={CharacterDetail}/>
        <Route path="/chats" component={ChatList}/>
        <Route path="/chat/:id" component={ChatView}/>
        <Route component={NotFound} />
      </Switch>
      
      {/* Show Bottom Nav on main root level screens */}
      <Switch>
        <Route path="/" component={BottomNav} />
        <Route path="/discover" component={BottomNav} />
        <Route path="/chats" component={BottomNav} />
        <Route path="/profile" component={BottomNav} />
      </Switch>
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
