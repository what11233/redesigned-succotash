import { useCharacters } from "@/hooks/use-characters";
import { useAuth } from "@/hooks/use-auth";
import { CharacterCard } from "@/components/CharacterCard";
import { AuthScreen } from "./AuthScreen";
import { Sparkles, Plus } from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";

export default function Home() {
  const { isAuthenticated, isLoading: authLoading } = useAuth();
  const { data: characters, isLoading: charsLoading } = useCharacters();

  if (authLoading) return <div className="min-h-screen bg-background" />;
  if (!isAuthenticated) return <AuthScreen />;

  return (
    <div className="min-h-[100dvh] bg-background pb-32 pt-12 px-4 md:px-8 max-w-5xl mx-auto">
      <header className="flex items-center justify-between mb-10">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground">For You</h1>
          <p className="text-muted-foreground">Discover new personalities</p>
        </div>
        <Link href="/create" className="w-12 h-12 rounded-full bg-card border border-border flex items-center justify-center text-primary hover:bg-primary hover:text-white transition-colors duration-300 shadow-lg">
          <Plus className="w-6 h-6" />
        </Link>
      </header>

      {charsLoading ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 animate-pulse">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <div key={i} className="aspect-[3/4] rounded-2xl bg-secondary/50" />
          ))}
        </div>
      ) : characters?.length === 0 ? (
        <motion.div 
          initial={{ opacity: 0 }} animate={{ opacity: 1 }}
          className="flex flex-col items-center justify-center py-20 text-center glass-panel rounded-3xl"
        >
          <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
            <Sparkles className="w-8 h-8 text-primary" />
          </div>
          <h3 className="text-xl font-display font-bold mb-2">No Characters Yet</h3>
          <p className="text-muted-foreground mb-6 max-w-sm">Be the first to create a unique personality for everyone to chat with.</p>
          <Link href="/create" className="px-6 py-3 rounded-full bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors">
            Create Character
          </Link>
        </motion.div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
          {characters?.map((char, i) => (
            <CharacterCard key={char.id} character={char} index={i} />
          ))}
        </div>
      )}
    </div>
  );
}
