import { motion } from "framer-motion";
import { Sparkles } from "lucide-react";

export function AuthScreen() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-[100dvh] flex items-center justify-center p-4 relative overflow-hidden bg-background">
      {/* Background decoration */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-[120px] mix-blend-screen" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/20 rounded-full blur-[120px] mix-blend-screen" />

      <motion.div 
        className="w-full max-w-md flex flex-col items-center text-center relative z-10"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
      >
        <div className="w-20 h-20 bg-gradient-to-br from-primary to-accent rounded-2xl flex items-center justify-center shadow-lg shadow-primary/20 mb-8 rotate-12">
          <Sparkles className="w-10 h-10 text-white -rotate-12" />
        </div>
        
        <h1 className="text-4xl md:text-5xl font-display font-bold mb-4">
          Unleash Your <br/>
          <span className="text-gradient">Imagination</span>
        </h1>
        
        <p className="text-muted-foreground text-lg mb-10 max-w-sm">
          Connect with unique AI characters, shape your story, and build meaningful relationships in a limitless world.
        </p>

        <button 
          onClick={handleLogin}
          className="w-full sm:w-auto px-8 py-4 rounded-full bg-white text-black font-display font-bold text-lg shadow-[0_0_40px_-10px_rgba(255,255,255,0.5)] hover:scale-105 active:scale-95 transition-all duration-300"
        >
          Continue with Replit
        </button>
      </motion.div>
    </div>
  );
}
