import { useChats, useDeleteChat } from "@/hooks/use-chats";
import { Link } from "wouter";
import { MessageCircle, Trash2, Heart } from "lucide-react";
import { motion } from "framer-motion";
import { formatDistanceToNow } from "date-fns";

export function ChatList() {
  const { data: chats, isLoading } = useChats();
  const { mutate: deleteChat } = useDeleteChat();

  if (isLoading) return <div className="min-h-screen bg-background" />;

  return (
    <div className="min-h-[100dvh] bg-background pb-32 pt-12 px-4 md:px-8 max-w-4xl mx-auto">
      <header className="mb-10">
        <h1 className="text-3xl font-display font-bold text-foreground">Your Connections</h1>
        <p className="text-muted-foreground">Continue where you left off</p>
      </header>

      {(!chats || chats.length === 0) ? (
        <div className="flex flex-col items-center justify-center py-20 text-center glass-panel rounded-3xl">
          <div className="w-16 h-16 rounded-full bg-secondary flex items-center justify-center mb-4">
            <MessageCircle className="w-8 h-8 text-muted-foreground" />
          </div>
          <h3 className="text-xl font-display font-bold mb-2">No Active Chats</h3>
          <p className="text-muted-foreground mb-6 max-w-sm">Head over to the home page to discover new characters.</p>
          <Link href="/" className="px-6 py-3 rounded-full bg-primary/10 text-primary font-medium hover:bg-primary/20 transition-colors">
            Explore Characters
          </Link>
        </div>
      ) : (
        <div className="space-y-4">
          {chats.map((item, i) => {
            const { chat, character } = item;
            const fallbackImg = `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(character.name)}`;
            const imgSource = character.imageUrl || fallbackImg;
            
            return (
              <motion.div 
                key={chat.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="group flex items-center justify-between p-4 glass-panel rounded-2xl hover:bg-card/80 transition-colors"
              >
                <Link href={`/chat/${chat.id}`} className="flex-1 flex items-center gap-4">
                  <div className="relative">
                    <img src={imgSource} alt={character.name} className="w-16 h-16 rounded-full object-cover border-2 border-border" />
                    {chat.relationshipMeter > 30 && (
                      <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-background rounded-full flex items-center justify-center">
                        <Heart className="w-3.5 h-3.5 text-primary fill-primary" />
                      </div>
                    )}
                  </div>
                  <div>
                    <h3 className="font-display font-bold text-lg leading-tight">{character.name}</h3>
                    <p className="text-sm text-muted-foreground">
                      Relationship: {chat.relationshipMeter} • {formatDistanceToNow(new Date(chat.createdAt), { addSuffix: true })}
                    </p>
                  </div>
                </Link>
                
                <button 
                  onClick={(e) => {
                    e.preventDefault();
                    if(confirm("Delete this conversation?")) deleteChat(chat.id);
                  }}
                  className="w-10 h-10 rounded-full flex items-center justify-center text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition-colors ml-4"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
