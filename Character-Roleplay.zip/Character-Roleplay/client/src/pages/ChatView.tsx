import { useEffect, useRef, useState } from "react";
import { useParams, Link } from "wouter";
import { useChat } from "@/hooks/use-chats";
import { useChatStream } from "@/hooks/use-chat-stream";
import { ArrowLeft, Send, Loader2, MoreVertical } from "lucide-react";
import { RelationshipMeter } from "@/components/RelationshipMeter";
import { clsx } from "clsx";
import { motion, AnimatePresence } from "framer-motion";

export function ChatView() {
  const { id } = useParams();
  const chatId = parseInt(id!);
  const { data, isLoading } = useChat(chatId);
  const { sendMessage, streamingContent, isStreaming, relationshipUpdate } = useChatStream(chatId);
  const [input, setInput] = useState("");
  
  const endOfMessagesRef = useRef<HTMLDivElement>(null);

  // Auto-scroll logic
  const scrollToBottom = () => {
    endOfMessagesRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [data?.messages, streamingContent]);

  if (isLoading) return <div className="min-h-screen bg-background flex items-center justify-center"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>;
  if (!data) return <div className="min-h-screen bg-background flex items-center justify-center">Chat not found</div>;

  const { chat, character, messages } = data;
  
  // Combine DB messages with currently streaming message
  const displayMessages = [...messages];
  if (isStreaming) {
    // If the last DB message is from user, the stream is the assistant's reply
    if (messages[messages.length - 1]?.role === 'user') {
      displayMessages.push({
        id: 999999, // temp id
        chatId,
        role: "assistant",
        content: streamingContent,
        createdAt: new Date()
      } as any);
    }
  }

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isStreaming) return;
    
    const msg = input.trim();
    setInput("");
    sendMessage(msg);
  };

  // Determine displayed relationship score (stream takes precedence if active)
  const currentRelScore = relationshipUpdate !== null ? relationshipUpdate : chat.relationshipMeter;

  // Function to render text with asterisks as italics
  const renderMessageContent = (content: string) => {
    const parts = content.split(/(\*.*?\*)/g);
    return parts.map((part, i) => {
      if (part.startsWith('*') && part.endsWith('*')) {
        return <em key={i} className="text-muted-foreground opacity-80">{part}</em>;
      }
      return part;
    });
  };

  return (
    <div className="flex flex-col h-[100dvh] bg-background">
      {/* Header */}
      <header className="glass-panel z-10 px-4 py-3 flex items-center justify-between sticky top-0">
        <div className="flex items-center gap-3">
          <Link href="/chats" className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-secondary transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div className="flex items-center gap-3">
            <img 
              src={character.imageUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${character.name}`} 
              alt={character.name} 
              className="w-10 h-10 rounded-full object-cover border border-border"
            />
            <div>
              <h2 className="font-display font-bold text-sm leading-tight">{character.name}</h2>
              <div className="text-[10px] text-primary">Online</div>
            </div>
          </div>
        </div>
        <RelationshipMeter score={currentRelScore} size="sm" />
      </header>

      {/* Chat Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6 pb-6">
        <AnimatePresence initial={false}>
          {displayMessages.map((msg, idx) => {
            const isUser = msg.role === 'user';
            const isStream = msg.id === 999999;
            
            return (
              <motion.div 
                key={msg.id}
                initial={isStream ? false : { opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={clsx("flex", isUser ? "justify-end" : "justify-start")}
              >
                {!isUser && (
                  <img 
                    src={character.imageUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${character.name}`} 
                    className="w-8 h-8 rounded-full object-cover mr-2 self-end mb-1"
                    alt=""
                  />
                )}
                <div className={clsx(
                  "max-w-[80%] rounded-2xl px-4 py-3 shadow-sm",
                  isUser 
                    ? "bg-primary text-white rounded-br-sm" 
                    : "bg-secondary text-secondary-foreground rounded-bl-sm border border-white/5",
                  isStream && !streamingContent && "animate-pulse" // Loading state for stream
                )}>
                  {isStream && !streamingContent ? (
                    <div className="flex gap-1 py-2">
                      <div className="w-2 h-2 rounded-full bg-muted-foreground animate-bounce" />
                      <div className="w-2 h-2 rounded-full bg-muted-foreground animate-bounce delay-75" />
                      <div className="w-2 h-2 rounded-full bg-muted-foreground animate-bounce delay-150" />
                    </div>
                  ) : (
                    <p className="leading-relaxed whitespace-pre-wrap text-[15px]">{renderMessageContent(msg.content)}</p>
                  )}
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
        <div ref={endOfMessagesRef} className="h-2" />
      </div>

      {/* Input Area */}
      <div className="p-4 glass-panel border-t border-white/5 mb-0 pb-safe">
        <form onSubmit={handleSend} className="relative flex items-center">
          <input 
            type="text"
            value={input}
            onChange={e => setInput(e.target.value)}
            disabled={isStreaming}
            placeholder="Type your message..."
            className="w-full bg-input/50 backdrop-blur-md border border-border rounded-full pl-5 pr-12 py-4 text-foreground focus:outline-none focus:ring-1 focus:ring-primary/50 transition-all disabled:opacity-50"
          />
          <button 
            type="submit"
            disabled={!input.trim() || isStreaming}
            className="absolute right-2 w-10 h-10 rounded-full bg-primary flex items-center justify-center text-white hover:scale-105 active:scale-95 transition-all disabled:opacity-50 disabled:hover:scale-100 shadow-md shadow-primary/20"
          >
            <Send className="w-4 h-4 ml-0.5" />
          </button>
        </form>
      </div>
    </div>
  );
}
