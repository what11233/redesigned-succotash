import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useCreateCharacter } from "@/hooks/use-characters";
import { useLocation } from "wouter";
import { ArrowLeft, Wand2, Loader2 } from "lucide-react";
import { Link } from "wouter";
import { clsx } from "clsx";

// Simulating the schema normally imported from @shared/schema
const formSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters").max(50),
  scenario: z.string().min(10, "Describe the setting or premise in detail"),
  personalityTraits: z.string().min(3, "E.g. Tsundere, Smart, Funny"),
  firstMessage: z.string().min(5, "What do they say to start the chat?"),
  imageUrl: z.string().url().optional().or(z.literal('')),
});

type FormValues = z.infer<typeof formSchema>;

export function CreateCharacter() {
  const [, setLocation] = useLocation();
  const { mutate, isPending } = useCreateCharacter();

  const { register, handleSubmit, formState: { errors } } = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: { name: "", scenario: "", personalityTraits: "", firstMessage: "", imageUrl: "" }
  });

  const onSubmit = (data: FormValues) => {
    mutate(data, {
      onSuccess: () => {
        setLocation('/');
      }
    });
  };

  const InputWrapper = ({ label, description, error, children }: { label: string, description?: string, error?: string, children: React.ReactNode }) => (
    <div className="flex flex-col gap-2">
      <div className="flex flex-col">
        <label className="text-sm font-bold tracking-wide text-muted-foreground uppercase">{label}</label>
        {description && <span className="text-xs text-muted-foreground/60 normal-case mb-1">{description}</span>}
      </div>
      {children}
      {error && <span className="text-destructive text-sm font-medium">{error}</span>}
    </div>
  );

  return (
    <div className="min-h-[100dvh] bg-background pb-32 pt-6 px-4 md:px-8 max-w-3xl mx-auto">
      <header className="flex items-center gap-4 mb-8">
        <Link href="/" className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center text-foreground hover:bg-secondary/80 transition-colors">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <h1 className="text-2xl font-display font-bold">Forge a Persona</h1>
      </header>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6 glass-panel p-6 md:p-8 rounded-3xl">
        <InputWrapper label="Character Name" error={errors.name?.message}>
          <input 
            {...register("name")} 
            className="w-full bg-input border border-border rounded-xl px-4 py-3 text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
            placeholder="e.g. Cyber-Ninja Kaito"
          />
        </InputWrapper>

        <InputWrapper label="Personality Traits (Comma separated)" error={errors.personalityTraits?.message}>
          <input 
            {...register("personalityTraits")} 
            className="w-full bg-input border border-border rounded-xl px-4 py-3 text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
            placeholder="e.g. Sarcastic, Highly intelligent, Protective"
          />
        </InputWrapper>

        <InputWrapper label="Scenario / Premise" error={errors.scenario?.message}>
          <textarea 
            {...register("scenario")} 
            rows={4}
            className="w-full bg-input border border-border rounded-xl px-4 py-3 text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all resize-none"
            placeholder="Describe the world, their background, and your relationship..."
          />
        </InputWrapper>

        <InputWrapper label="First Message" error={errors.firstMessage?.message}>
          <textarea 
            {...register("firstMessage")} 
            rows={3}
            className="w-full bg-input border border-border rounded-xl px-4 py-3 text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all resize-none"
            placeholder="What is the first thing they say when you meet?"
          />
        </InputWrapper>

        <InputWrapper 
          label="Avatar Photo URL" 
          description="Link to a photo or avatar for your character"
          error={errors.imageUrl?.message}
        >
          <input 
            {...register("imageUrl")} 
            className="w-full bg-input border border-border rounded-xl px-4 py-3 text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
            placeholder="https://images.unsplash.com/photo-..."
          />
        </InputWrapper>

        <button 
          type="submit" 
          disabled={isPending}
          className={clsx(
            "w-full flex items-center justify-center gap-2 py-4 rounded-xl font-bold text-lg transition-all mt-8",
            isPending 
              ? "bg-muted text-muted-foreground cursor-not-allowed" 
              : "bg-gradient-to-r from-primary to-accent text-white shadow-lg shadow-primary/20 hover:shadow-xl hover:-translate-y-0.5"
          )}
        >
          {isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : <Wand2 className="w-5 h-5" />}
          {isPending ? "Manifesting..." : "Create Character"}
        </button>
      </form>
    </div>
  );
}
