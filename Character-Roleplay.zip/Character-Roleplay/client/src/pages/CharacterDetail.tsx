import { useParams, useLocation } from "wouter";
import { useCharacter } from "@/hooks/use-characters";
import { useCreateChat } from "@/hooks/use-chats";
import { ArrowLeft, MessageSquare, Loader2 } from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";

export function CharacterDetail() {
  const params = useParams();
  const [, setLocation] = useLocation();
  const charId = params.id ? parseInt(params.id) : null;
  const { data: character, isLoading } = useCharacter(charId);
  const { mutate: createChat, isPending } = useCreateChat();

  if (isLoading) return <div className="min-h-screen bg-background" />;
  if (!character) return <div className="min-h-screen flex items-center justify-center text-muted-foreground">Character not found</div>;

  const fallbackImg = `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(character.name)}&backgroundColor=b6e3f4,c0aede,d1d4f9,ffdfbf`;
  const imgSource = character.imageUrl || fallbackImg;

  const handleStartChat = () => {
    createChat(character.id, {
      onSuccess: (chat) => {
        setLocation(`/chat/${chat.id}`);
      }
    });
  };

  return (
    <div className="min-h-[100dvh] bg-background">
      <Link href="/" className="absolute top-6 left-6 z-20 w-10 h-10 rounded-full glass-panel flex items-center justify-center text-white hover:bg-white/20 transition-colors">
        <ArrowLeft className="w-5 h-5" />
      </Link>

      <div className="relative h-[60vh] w-full">
        <img src={imgSource} alt={character.name} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative z-10 px-6 pb-32 -mt-32 max-w-2xl mx-auto"
      >
        <h1 className="text-5xl font-display font-bold text-white mb-2">{character.name}</h1>
        <div className="flex flex-wrap gap-2 mb-8">
          {character.personalityTraits.split(',').map((trait: string, i: number) => (
            <span key={i} className="px-3 py-1 rounded-full bg-secondary text-secondary-foreground text-sm font-medium border border-white/5">
              {trait.trim()}
            </span>
          ))}
        </div>

        <div className="space-y-8">
          <section>
            <h3 className="text-sm uppercase tracking-widest text-muted-foreground mb-3 font-bold">Scenario</h3>
            <p className="text-foreground leading-relaxed text-lg">{character.scenario}</p>
          </section>
          
          <section className="glass-panel p-6 rounded-2xl">
            <h3 className="text-sm uppercase tracking-widest text-muted-foreground mb-3 font-bold">First Message</h3>
            <p className="text-foreground italic">"{character.firstMessage}"</p>
          </section>
        </div>

        <div className="fixed bottom-0 left-0 right-0 p-6 glass-panel border-t border-white/10 z-50">
          <div className="max-w-2xl mx-auto">
            <button 
              onClick={handleStartChat}
              disabled={isPending}
              className="w-full flex items-center justify-center gap-2 py-4 rounded-xl bg-gradient-to-r from-primary to-accent text-white font-bold text-lg hover:shadow-lg hover:shadow-primary/30 transition-all disabled:opacity-50"
            >
              {isPending ? <Loader2 className="w-6 h-6 animate-spin" /> : <MessageSquare className="w-6 h-6" />}
              {isPending ? "Starting..." : "Start Chatting"}
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
