import { useState, useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";

export function useChatStream(chatId: number) {
  const queryClient = useQueryClient();
  const [streamingContent, setStreamingContent] = useState("");
  const [isStreaming, setIsStreaming] = useState(false);
  const [relationshipUpdate, setRelationshipUpdate] = useState<number | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  const stopStreaming = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
      setIsStreaming(false);
    }
  };

  const sendMessage = async (content: string) => {
    if (isStreaming) return;
    
    setIsStreaming(true);
    setStreamingContent("");
    setRelationshipUpdate(null);
    abortControllerRef.current = new AbortController();

    try {
      const res = await fetch(`/api/chats/${chatId}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content }),
        credentials: "include",
        signal: abortControllerRef.current.signal
      });

      if (!res.ok) throw new Error("Failed to start message stream");
      if (!res.body) throw new Error("No response body");

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n\n");
        buffer = lines.pop() || ""; // keep incomplete chunk

        for (const line of lines) {
          if (line.startsWith("data: ")) {
            try {
              const data = JSON.parse(line.slice(6));
              
              if (data.content) {
                setStreamingContent(prev => prev + data.content);
              }
              
              if (data.relationshipUpdate !== undefined) {
                setRelationshipUpdate(data.relationshipUpdate);
              }

              if (data.done) {
                setIsStreaming(false);
                // Invalidate to fetch the final saved messages from DB
                queryClient.invalidateQueries({ queryKey: [api.chats.get.path, chatId] });
              }
              
              if (data.error) {
                console.error("Stream error:", data.error);
                setIsStreaming(false);
              }
            } catch (e) {
              console.error("Failed to parse chunk", e);
            }
          }
        }
      }
    } catch (err: any) {
      if (err.name === 'AbortError') {
        console.log('Stream aborted');
      } else {
        console.error("Streaming failed:", err);
      }
      setIsStreaming(false);
    }
  };

  return { 
    sendMessage, 
    streamingContent, 
    isStreaming, 
    stopStreaming,
    relationshipUpdate 
  };
}
