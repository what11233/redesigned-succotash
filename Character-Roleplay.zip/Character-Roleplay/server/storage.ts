import { db } from "./db";
import {
  characters,
  chats,
  messages,
  users,
  type Character,
  type InsertCharacter,
  type Chat,
  type InsertChat,
  type Message,
  type InsertMessage,
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // Characters
  getCharacters(): Promise<Character[]>;
  getCharacter(id: number): Promise<Character | undefined>;
  createCharacter(character: InsertCharacter, creatorId?: string): Promise<Character>;
  
  // Chats
  getChatsForUser(userId: string): Promise<{ chat: Chat; character: Character }[]>;
  getChat(id: number): Promise<Chat | undefined>;
  createChat(chat: InsertChat, userId: string): Promise<Chat>;
  deleteChat(id: number): Promise<void>;
  updateChatRelationship(id: number, delta: number): Promise<Chat>;

  // Messages
  getMessages(chatId: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
}

export class DatabaseStorage implements IStorage {
  async getCharacters(): Promise<Character[]> {
    return await db.select().from(characters);
  }

  async getCharacter(id: number): Promise<Character | undefined> {
    const [character] = await db.select().from(characters).where(eq(characters.id, id));
    return character;
  }

  async createCharacter(character: InsertCharacter, creatorId?: string): Promise<Character> {
    const [newChar] = await db.insert(characters).values({ ...character, creatorId }).returning();
    return newChar;
  }

  async getChatsForUser(userId: string): Promise<{ chat: Chat; character: Character }[]> {
    const results = await db.select({
      chat: chats,
      character: characters
    })
    .from(chats)
    .innerJoin(characters, eq(chats.characterId, characters.id))
    .where(eq(chats.userId, userId))
    .orderBy(desc(chats.createdAt));
    return results;
  }

  async getChat(id: number): Promise<Chat | undefined> {
    const [chat] = await db.select().from(chats).where(eq(chats.id, id));
    return chat;
  }

  async createChat(chat: InsertChat, userId: string): Promise<Chat> {
    const [newChat] = await db.insert(chats).values({ ...chat, userId }).returning();
    return newChat;
  }

  async deleteChat(id: number): Promise<void> {
    await db.delete(chats).where(eq(chats.id, id));
  }

  async updateChatRelationship(id: number, delta: number): Promise<Chat> {
    const chat = await this.getChat(id);
    if (!chat) throw new Error("Chat not found");
    const newMeter = Math.max(-100, Math.min(100, chat.relationshipMeter + delta));
    const [updatedChat] = await db.update(chats)
      .set({ relationshipMeter: newMeter })
      .where(eq(chats.id, id))
      .returning();
    return updatedChat;
  }

  async getMessages(chatId: number): Promise<Message[]> {
    return await db.select().from(messages).where(eq(messages.chatId, chatId)).orderBy(messages.createdAt);
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const [newMsg] = await db.insert(messages).values(message).returning();
    return newMsg;
  }
}

export const storage = new DatabaseStorage();
