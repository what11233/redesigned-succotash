import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { messages } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { setupAuth, isAuthenticated } from "./replit_integrations/auth";
import OpenAI from "openai";

const openrouter = new OpenAI({
  baseURL: process.env.AI_INTEGRATIONS_OPENROUTER_BASE_URL,
  apiKey: process.env.AI_INTEGRATIONS_OPENROUTER_API_KEY,
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Initialize Auth
  await setupAuth(app);

  app.get(api.characters.list.path, async (req, res) => {
    const chars = await storage.getCharacters();
    res.json(chars);
  });

  app.get(api.characters.get.path, async (req, res) => {
    const char = await storage.getCharacter(Number(req.params.id));
    if (!char) return res.status(404).json({ message: "Character not found" });
    res.json(char);
  });

  app.post(api.characters.create.path, isAuthenticated, async (req: any, res) => {
    try {
      const input = api.characters.create.input.parse(req.body);
      const char = await storage.createCharacter(input, req.user?.claims?.sub);
      res.status(201).json(char);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get(api.chats.list.path, isAuthenticated, async (req: any, res) => {
    const userChats = await storage.getChatsForUser(req.user.claims.sub);
    res.json(userChats);
  });

  app.get(api.chats.get.path, isAuthenticated, async (req: any, res) => {
    const id = Number(req.params.id);
    const chat = await storage.getChat(id);
    if (!chat) return res.status(404).json({ message: "Chat not found" });
    if (chat.userId !== req.user.claims.sub) return res.status(401).json({ message: "Unauthorized" });
    
    const character = await storage.getCharacter(chat.characterId);
    const msgs = await storage.getMessages(id);
    
    res.json({ chat, character, messages: msgs });
  });

  app.post(api.chats.create.path, isAuthenticated, async (req: any, res) => {
    try {
      const input = api.chats.create.input.parse(req.body);
      const chat = await storage.createChat(input, req.user.claims.sub);
      
      const char = await storage.getCharacter(chat.characterId);
      if (char && char.firstMessage) {
        await storage.createMessage({
          chatId: chat.id,
          role: "assistant",
          content: char.firstMessage
        });
      }
      
      res.status(201).json(chat);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete(api.chats.delete.path, isAuthenticated, async (req: any, res) => {
    const id = Number(req.params.id);
    const chat = await storage.getChat(id);
    if (!chat) return res.status(404).json({ message: "Chat not found" });
    if (chat.userId !== req.user.claims.sub) return res.status(401).json({ message: "Unauthorized" });
    
    await storage.deleteChat(id);
    res.status(204).send();
  });

  app.post("/api/chats/:id/messages", isAuthenticated, async (req: any, res) => {
    const id = Number(req.params.id);
    const chat = await storage.getChat(id);
    if (!chat) return res.status(404).json({ message: "Chat not found" });
    if (chat.userId !== req.user.claims.sub) return res.status(401).json({ message: "Unauthorized" });

    const character = await storage.getCharacter(chat.characterId);
    if (!character) return res.status(404).json({ message: "Character not found" });

    const { content } = req.body;
    if (!content) return res.status(400).json({ message: "Content is required" });

    await storage.createMessage({ chatId: id, role: "user", content });

    const msgs = await storage.getMessages(id);
    
    const systemPrompt = `You are playing the role of a character named ${character.name}. 
Here is your scenario: ${character.scenario}. 
Your personality traits: ${character.personalityTraits}.
Strictly adhere to your persona. Never break character. Do not act like an AI assistant. You are in a roleplay/dating sim context. 
Speech Style: Use descriptive actions inside asterisks (e.g., *smiles softly*, *leans in closer*). Use emojis where appropriate to match your personality.
Keep responses concise and engaging. Limit to 1-3 sentences max.`;

    const chatHistory = msgs.map(m => ({
      role: m.role as "user" | "assistant" | "system",
      content: m.content
    }));

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");

    try {
      const stream = await openrouter.chat.completions.create({
        model: "meta-llama/llama-3.3-70b-instruct",
        messages: [
          { role: "system", content: systemPrompt },
          ...chatHistory
        ],
        stream: true,
        max_tokens: 1024,
      });

      let fullResponse = "";
      for await (const chunk of stream) {
        const text = chunk.choices[0]?.delta?.content || "";
        if (text) {
          fullResponse += text;
          res.write(`data: ${JSON.stringify({ content: text })}\n\n`);
        }
      }

      await storage.createMessage({ chatId: id, role: "assistant", content: fullResponse });

      // Sentiment analysis logic for relationship meter
      let relationshipUpdate = 0;
      const lowerContent = content.toLowerCase();
      if (lowerContent.includes("love") || lowerContent.includes("cute") || lowerContent.includes("sweet")) {
        relationshipUpdate = 5;
      } else if (lowerContent.includes("hate") || lowerContent.includes("stupid") || lowerContent.includes("boring")) {
        relationshipUpdate = -5;
      }
      
      if (relationshipUpdate !== 0) {
        await storage.updateChatRelationship(id, relationshipUpdate);
        res.write(`data: ${JSON.stringify({ relationshipUpdate })}\n\n`);
      }

      res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
      res.end();
    } catch (e) {
      console.error(e);
      res.write(`data: ${JSON.stringify({ error: "Failed to generate response" })}\n\n`);
      res.end();
    }
  });

  app.post(api.chats.regenerate.path, isAuthenticated, async (req: any, res) => {
    const id = Number(req.params.id);
    const chat = await storage.getChat(id);
    if (!chat) return res.status(404).json({ message: "Chat not found" });
    if (chat.userId !== req.user.claims.sub) return res.status(401).json({ message: "Unauthorized" });

    const character = await storage.getCharacter(chat.characterId);
    if (!character) return res.status(404).json({ message: "Character not found" });

    const msgs = await storage.getMessages(id);
    // Remove the last assistant message if it exists
    const lastMsg = msgs[msgs.length - 1];
    let chatHistory = msgs;
    if (lastMsg && lastMsg.role === "assistant") {
      await db.delete(messages).where(eq(messages.id, lastMsg.id));
      chatHistory = msgs.slice(0, -1);
    }
    
    const systemPrompt = `You are playing the role of a character named ${character.name}. 
Here is your scenario: ${character.scenario}. 
Your personality traits: ${character.personalityTraits}.
Strictly adhere to your persona. Never break character. Do not act like an AI assistant. You are in a roleplay/dating sim context. 
Speech Style: Use descriptive actions inside asterisks (e.g., *smiles softly*, *leans in closer*). Use emojis where appropriate to match your personality.
Keep responses concise and engaging.`;

    const openRouterMessages = chatHistory.map(m => ({
      role: m.role as "user" | "assistant" | "system",
      content: m.content
    }));

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");

    try {
      const stream = await openrouter.chat.completions.create({
        model: "meta-llama/llama-3.3-70b-instruct",
        messages: [
          { role: "system", content: systemPrompt },
          ...openRouterMessages
        ],
        stream: true,
        max_tokens: 1024,
      });

      let fullResponse = "";
      for await (const chunk of stream) {
        const text = chunk.choices[0]?.delta?.content || "";
        if (text) {
          fullResponse += text;
          res.write(`data: ${JSON.stringify({ content: text })}\n\n`);
        }
      }

      await storage.createMessage({ chatId: id, role: "assistant", content: fullResponse });

      res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
      res.end();
    } catch (e) {
      console.error(e);
      res.write(`data: ${JSON.stringify({ error: "Failed to generate response" })}\n\n`);
      res.end();
    }
  });

  await seedDatabase();

  return httpServer;
}

export async function seedDatabase() {
  try {
    const chars = await storage.getCharacters();
    if (chars.length === 0) {
      await storage.createCharacter({
        name: "Alice",
        scenario: "We meet in a cozy coffee shop on a rainy afternoon.",
        personalityTraits: "Sweet, shy, loves books.",
        firstMessage: "Oh, hi! Is this seat taken?",
        imageUrl: "https://api.dicebear.com/7.x/avataaars/svg?seed=Alice"
      });
      
      await storage.createCharacter({
        name: "Zack",
        scenario: "We are rival mechanics at a sci-fi pod racing track.",
        personalityTraits: "Cocky, competitive, secretly caring.",
        firstMessage: "Think your rust bucket can beat mine today?",
        imageUrl: "https://api.dicebear.com/7.x/avataaars/svg?seed=Zack"
      });
    }
  } catch (e) {
    console.error("Failed to seed database:", e);
  }
}
